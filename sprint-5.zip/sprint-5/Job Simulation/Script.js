// Selecting DOM elements
const addStudentBtn = document.getElementById('add-student-btn');
const studentNameInput = document.getElementById('student-name-input');
const studentList = document.getElementById('student-list');
const totalStudentsDisplay = document.getElementById('total-students');

// Function to update the total number of students
const updateTotalStudents = () => {
    totalStudentsDisplay.textContent = studentList.children.length;
};

// Function to create a new list item for a student
const createStudentItem = (name) => {
    const li = document.createElement('li');
    li.innerHTML = `
        ${name}
        <button class="edit-btn">Edit</button>
        <button class="delete-btn">Delete</button>
    `;
    
    // Add event listener for the edit button
    li.querySelector('.edit-btn').addEventListener('click', () => editStudent(li, name));

    // Add event listener for the delete button
    li.querySelector('.delete-btn').addEventListener('click', () => deleteStudent(li));

    studentList.appendChild(li);
    updateTotalStudents();
};

// Function to add a student
const addStudent = () => {
    const studentName = studentNameInput.value.trim();
    if (studentName === '') {
        alert('Please enter a valid student name.');
        return;
    }
    createStudentItem(studentName);
    studentNameInput.value = ''; // Clear input field after adding
};

// Function to edit a student's name
const editStudent = (li, oldName) => {
    const newName = prompt('Edit student name:', oldName);
    if (newName !== null && newName.trim() !== '') {
        li.firstChild.textContent = newName;
    }
};

// Function to delete a student
const deleteStudent = (li) => {
    studentList.removeChild(li);
    updateTotalStudents();
};

// Event listener to add student on button click
addStudentBtn.addEventListener('click', addStudent);

// Optional: Allow pressing 'Enter' to add student
studentNameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        addStudent();
    }
});
