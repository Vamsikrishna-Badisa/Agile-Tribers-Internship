document.getElementById('userForm').addEventListener('submit', function (e) {
  e.preventDefault();

  // Get input values
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const age = document.getElementById('age').value.trim();

  // Error elements
  const nameError = document.getElementById('nameError');
  const emailError = document.getElementById('emailError');
  const ageError = document.getElementById('ageError');

  // Reset errors
  nameError.textContent = '';
  emailError.textContent = '';
  ageError.textContent = '';

  let valid = true;

  // Validation
  if (name === '') {
    nameError.textContent = 'Name is required.';
    valid = false;
  }

  if (!email.match(/^\S+@\S+\.\S+$/)) {
    emailError.textContent = 'Enter a valid email address.';
    valid = false;
  }

  if (age === '' || isNaN(age) || Number(age) <= 0) {
    ageError.textContent = 'Enter a valid age.';
    valid = false;
  }

  if (!valid) return;

  // Store in localStorage
  const userData = { name, email, age };
  localStorage.setItem('userData', JSON.stringify(userData));

  // Redirect
  window.location.href = 'display.html';
});
