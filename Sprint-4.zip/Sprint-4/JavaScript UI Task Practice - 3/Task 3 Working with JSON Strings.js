const jsonString = `{
    "name": "Vamsi Krishna Badisa",
    "email": "vamsibadisabadisa126@gmail.com",
    "skills": ["JavaScript", "React", "Node.js"]
  }`;

  const userObject = JSON.parse(jsonString);
  
  console.log("Name:", userObject.name);
  console.log("Email:", userObject.email);
  console.log("Skills:", userObject.skills);
  