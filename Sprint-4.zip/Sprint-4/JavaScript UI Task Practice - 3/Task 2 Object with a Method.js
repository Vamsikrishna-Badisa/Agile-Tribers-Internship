let user = {
  firstName: "Vamsi",
  lastName: "Krishna",
  getFullName: function() {
    return this.firstName + " " + this.lastName;
  }
};

console.log("Full Name:", user.getFullName());
