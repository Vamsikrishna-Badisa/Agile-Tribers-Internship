let person = {
  name: "Vamsi Krishna",
  age: 30,
  city: "Chennai"
};

console.log("Name:", person.name);
console.log("Age:", person.age);
console.log("City:", person.city);

person.age = 20;

console.log("Updated Person:", person);
