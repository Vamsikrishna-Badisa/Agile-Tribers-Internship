// Declare variables
let a = 10;
let b = 30;
let c = 12;
let d = 3;

// Perform the arithmetic: (a + b) * c / d
let result = (a + b) * c / d;

// Print the result
console.log("Result of (a + b) * c / d is:", result);
