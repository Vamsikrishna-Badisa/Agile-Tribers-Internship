// Declare a constant
const PI = 3.14159;

console.log("Original value of PI:", PI);

// Attempt to reassign the constant
PI = 3.14; // This will cause an error

console.log("New value of PI:", PI);
