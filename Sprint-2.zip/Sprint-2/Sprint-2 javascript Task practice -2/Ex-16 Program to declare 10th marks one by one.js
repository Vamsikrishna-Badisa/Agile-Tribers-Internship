// Declare marks for each subject
let tamil = 85;
let english = 78;
let maths = 92;
let science = 88;
let social = 81;

// Calculate total marks
let total = tamil + english + maths + science + social;

// Calculate average
let average = total / 5;

// Print the results
console.log("Marks:");
console.log("Tamil:", tamil);
console.log("English:", english);
console.log("Maths:", maths);
console.log("Science:", science);
console.log("Social:", social);
console.log("------------------------");
console.log("Total Marks:", total);
console.log("Average Marks:", average);