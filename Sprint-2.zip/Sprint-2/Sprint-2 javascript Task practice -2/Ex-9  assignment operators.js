// Start with a variable
let number = 10;
console.log("Initial value:", number);

// Use += to add and assign
number += 5; // equivalent to: number = number + 5
console.log("After += 5:", number);

// Use -= to subtract and assign
number -= 3; // equivalent to: number = number - 3
console.log("After -= 3:", number);

// Use *= to multiply and assign
number *= 2; // equivalent to: number = number * 2
console.log("After *= 2:", number);

// Use /= to divide and assign
number /= 4; // equivalent to: number = number / 4
console.log("After /= 4:", number);
