// Declare the numbers
let num1 = 10;
let num2 = 20;
let num3 = 30;
let num4 = 40;
let num5 = 50;

// Calculate the sum
let sum = num1 + num2 + num3 + num4 + num5;

// Calculate the average
let average = sum / 5;

// Print the result
console.log("The average of the numbers is:", average);
