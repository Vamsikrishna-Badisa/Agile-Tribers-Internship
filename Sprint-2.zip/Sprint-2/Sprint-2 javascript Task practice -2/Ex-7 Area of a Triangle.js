// Declare base and height
let base = 8;
let height = 6;

// Calculate the area using the formula (base × height) / 2
let area = (base * height) / 2;

// Print the result
console.log("The area of a triangle with base", base, "and height", height, "is:", area);
