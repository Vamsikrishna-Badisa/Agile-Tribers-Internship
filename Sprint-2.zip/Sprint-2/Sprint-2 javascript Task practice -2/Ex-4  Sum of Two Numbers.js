// Declare two variables and assign number values
let num1 = 10;
let num2 = 25;

// Add the two numbers
let sum = num1 + num2;

// Print the result
console.log("The sum of", num1, "and", num2, "is:", sum);
