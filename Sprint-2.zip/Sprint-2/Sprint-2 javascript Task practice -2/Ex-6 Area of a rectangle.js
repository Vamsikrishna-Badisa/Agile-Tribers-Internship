// Declare length and width
let length = 10;
let width = 5;

// Calculate the area using the formula length × width
let area = length * width;

// Print the result
console.log("The area of a rectangle with length", length, "and width", width, "is:", area);
