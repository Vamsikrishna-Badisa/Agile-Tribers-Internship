// Declare the radius
let radius = 5;

// Define the value of π (pi)
const PI = 3.14159;

// Calculate the area using the formula πr²
let area = PI * radius * radius;

// Print the result
console.log("The area of a circle with radius", radius, "is:", area);
