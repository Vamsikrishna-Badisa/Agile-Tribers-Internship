// Declare two variables
let a = 10;
let b = "10";

// Comparison results
console.log("a == b:", a == b);     
console.log("a != b:", a != b);       
console.log("a === b:", a === b);    
console.log("a !== b:", a !== b);    
console.log("a > b:", a > b);         
console.log("a < b:", a < b);        
console.log("a >= b:", a >= b);      
console.log("a <= b:", a <= b);      
