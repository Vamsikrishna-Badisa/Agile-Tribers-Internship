let num1 = 20;
let num2 = 5;

let addition = num1 + num2;
let subtraction = num1 - num2;
let multiplication = num1 * num2;
let division = num1 / num2;

console.log("Addition: " + addition);         
console.log("Subtraction: " + subtraction);    
console.log("Multiplication: " + multiplication); 
console.log("Division: " + division);           
