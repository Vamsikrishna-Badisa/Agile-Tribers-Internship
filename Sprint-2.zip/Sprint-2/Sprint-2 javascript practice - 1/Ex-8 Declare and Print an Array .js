let fruits = ["Apple", "Banana", "Cherry", "Mango"];

for (let i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
}
