let name = "Alice Johnson";         
let age = 25;                          
let dob = "1999-08-15";                
let height = 5.6;                      
let weight = 60.5;                     
let degree = "Bachelor of Science";   
let gender = "Female";                 

console.log("Name:", name);
console.log("Age:", age);
console.log("Date of Birth:", dob);
console.log("Height:", height, "ft");
console.log("Weight:", weight, "kg");
console.log("Degree:", degree);
console.log("Gender:", gender);
