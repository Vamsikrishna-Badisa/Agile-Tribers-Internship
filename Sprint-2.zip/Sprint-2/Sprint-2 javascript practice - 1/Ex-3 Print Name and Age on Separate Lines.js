let name = "Alice";
let age = 25;

console.log("Name: " + name);
console.log("Age: " + age);
