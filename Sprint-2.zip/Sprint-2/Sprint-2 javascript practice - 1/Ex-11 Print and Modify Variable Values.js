let name = "Alice";
let age = 25;
let isStudent = true;

console.log("Original Values:");
console.log("Name:", name);
console.log("Age:", age);
console.log("Is Student:", isStudent);

name = "Bob";             
age = age + 1;           
isStudent = !isStudent;   

console.log("\nUpdated Values:");
console.log("Name:", name);
console.log("Age:", age);
console.log("Is Student:", isStudent);
