let name = "Vamsi Krishna";    
let age = 20;               
let isStudent = true;      

let greeting = "Hello, my name is " + name;
let nextYearAge = age + 1;
let studentStatus = "Am I a student? " + isStudent;

console.log(greeting);        
console.log("Next year I will be " + nextYearAge); 
console.log(studentStatus);   
