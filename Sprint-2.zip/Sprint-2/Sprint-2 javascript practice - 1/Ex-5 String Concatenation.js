let name = "Vamsi Krishna";    
let age = 20;             

let message = "My name is " + name + " and I am " + age + " years old.";

console.log(message);
