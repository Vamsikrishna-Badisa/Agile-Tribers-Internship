let numbers = [10, 20, 30, 40, 10];

if (numbers[0] === numbers[numbers.length - 1]) {
  console.log("Result: True");
} else {
  console.log("Result: False");
}
