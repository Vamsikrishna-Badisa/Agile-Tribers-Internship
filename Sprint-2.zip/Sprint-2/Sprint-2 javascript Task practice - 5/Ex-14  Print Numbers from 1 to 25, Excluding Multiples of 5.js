for i in range(1, 26):
    if i % 5 != 0:
        print(i)
