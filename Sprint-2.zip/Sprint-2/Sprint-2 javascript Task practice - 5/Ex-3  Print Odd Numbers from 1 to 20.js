for (let i = 1; i <= 20; i += 2) {
  console.log(i);
}
