let character = 'a';  // You can change this to any character

if (['a', 'e', 'i', 'o', 'u'].includes(character.toLowerCase())) {
  console.log(character + " is a vowel.");
} else {
  console.log(character + " is a consonant.");
}
