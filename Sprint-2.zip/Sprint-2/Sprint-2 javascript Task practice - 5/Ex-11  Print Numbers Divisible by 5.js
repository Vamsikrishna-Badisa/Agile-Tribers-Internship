let numbers = [10, 20, 33, 45, 50, 67, 80, 99];

for (let i = 0; i < numbers.length; i++) {
  if (numbers[i] % 5 === 0) {
    console.log(numbers[i]);
  }
}
