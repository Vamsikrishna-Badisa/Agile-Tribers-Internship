function square(num) {
    return num * num;
}

// Example usage:
console.log(square(4));    // Output: 16
console.log(square(7));    // Output: 49
console.log(square(-3));   // Output: 9
console.log(square(2.5));  // Output: 6.25
