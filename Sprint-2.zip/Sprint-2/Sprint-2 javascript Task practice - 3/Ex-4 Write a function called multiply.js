function multiply(a, b) {
    return a * b;
}

// Example usage:
console.log(multiply(6, 7));    // Output: 42
console.log(multiply(3, -4));   // Output: -12
console.log(multiply(2.5, 4));  // Output: 10
