// Define the function
function add(a, b) {
    return a + b;
}

// Call the function with different arguments and print the results
console.log(add(3, 5));        // Output: 8
console.log(add(10, 20));      // Output: 30
console.log(add(-4, 7));       // Output: 3
console.log(add(2.5, 4.3));    // Output: 6.8
