// Declare the function expression
const multiply = function(x, y) {
    return x * y;
};

// Call the function with different arguments and print the results
console.log(multiply(4, 5));     // Output: 20
console.log(multiply(7, 3));     // Output: 21
console.log(multiply(-2, 6));    // Output: -12
console.log(multiply(2.5, 4));   // Output: 10
